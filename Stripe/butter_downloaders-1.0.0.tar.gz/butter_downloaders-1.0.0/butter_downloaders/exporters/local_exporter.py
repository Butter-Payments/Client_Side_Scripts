import os
import shutil
from typing import List

from butter_downloaders.exporters import Exporter, objects_to_gzip_jsonl


class LocalExporter(Exporter):
    """
    Writes batches of objects to the local filesystem.
    """

    def open(self):
        if not os.path.exists("./files"):
            os.mkdir("./files")
        if not os.path.exists("./out"):
            os.mkdir("./out")

    def write_batch(self, from_datetime: str, to_datetime: str, objects: List[str]):
        file_name_gz = objects_to_gzip_jsonl(objects, from_datetime, to_datetime)
        print(file_name_gz)

    def close(self):
        shutil.make_archive("transactions", "tar", root_dir="./files")
        shutil.move("transactions.tar", "./out/transactions.tar")
