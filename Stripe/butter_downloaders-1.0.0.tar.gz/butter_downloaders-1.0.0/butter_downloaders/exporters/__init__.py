import datetime
import decimal
import gzip
import json
import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import List

import dateutil.parser


def custom_serializer(obj):
    """
    Serializes objects that aren't handled by JSON natively.
    """
    if isinstance(obj, (datetime.datetime, datetime.date)):
        return obj.isoformat()
    elif isinstance(obj, decimal.Decimal):
        return str(obj)
    raise TypeError("Object %s of type %s is not serializable" % (str(obj), type(obj)))


def objects_to_gzip_jsonl(objects: List, from_datetime: str, to_datetime: str) -> Path:
    """
    Serializes a list of objects and writes them to a gzipped json file.
    :param objects: A list of JSON objects to write to file.
    :param from_datetime: Beginning window of the object's created_at times, for filename construction
    :param to_datetime: Ending window of the object's created at time, for filename construction
    :return: A Path representing the .jsonl.gz's location within the container's filesystem
    """
    # Create subfolder if it doesn't exist
    Path("./files").mkdir(parents=True, exist_ok=True)
    file_name = (
        f"./files/transactions_{int(dateutil.parser.isoparse(from_datetime).timestamp())}"
        f"_{int(dateutil.parser.isoparse(to_datetime).timestamp())}.jsonl"
    )
    file_name_gz = f"{file_name}.gz"
    output_json = open(file_name, "w")
    for obj in objects:
        output_json.write(json.dumps(obj, default=custom_serializer))
    output_json.close()

    with open(file_name, "rb") as f_in, gzip.open(file_name_gz, "wb") as f_out:
        f_out.writelines(f_in)

    os.remove(file_name)
    return Path(file_name_gz)


class Exporter(ABC):
    """
    Base class for exporter.
    """

    def __init__(self):
        pass

    @abstractmethod
    def open(self):
        """
        Runs any initialization tasks required to export, opening any necessary streams or files.
        :return:
        """
        pass

    @abstractmethod
    def write_batch(self, from_datetime: str, to_datetime: str, objects: List[str]):
        """
        Writes a batch of records to a specified location.
        :param objects: A List of records.
        :param from_datetime: Starting datetime str
        :param to_datetime: Ending datetime str
        :return:
        """
        pass

    @abstractmethod
    def close(self):
        """
        Runs any finishing tasks, and closes any outstanding files or streams.
        :return:
        """
        pass
