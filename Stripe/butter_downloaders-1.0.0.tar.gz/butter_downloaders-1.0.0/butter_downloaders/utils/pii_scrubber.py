import hashlib

from butter_downloaders.config.pii_config import SCRUB_CONFIG


class PIIScrubber:
    """
    Class for scrubbing PII from PSP objects.
    """

    def __init__(self, psp: str, object_type: str):
        """
        Initializes the PIIScrubber with the PSP and object type. Also reads the pii_config.jsonc file
        to determine the fields which need to be either hashed or masked
        :param psp: The PSP to configure for
        :param object_type: The object type to configure for
        """
        self.psp = psp
        self.object_type = object_type

        config = SCRUB_CONFIG
        self.hash_fields, self.mask_fields = self.__parse_pii_config(
            config, psp, object_type
        )

    def __parse_pii_config(self, config, psp, obj_type):
        """
        Parses the pii_config.jsonc file to determine the fields which need to be either hashed or masked
        :param config: The PII config JSON object
        :param psp: The PSP to search for
        :param obj_type: The object type to search for
        :return: A tuple of lists of fields to hash and mask
        """
        hash_fields, mask_fields = [], []
        if psp not in config.keys():
            print("PSP not found in config")
            raise Exception()
        psp_config = config[psp]
        hash_fields += psp_config["generic"]["hash"]
        mask_fields += psp_config["generic"]["mask"]
        if obj_type not in psp_config.keys():
            return hash_fields, mask_fields
        if "hash" in psp_config[obj_type].keys():
            hash_fields += psp_config[obj_type]["hash"]
        if "mask" in psp_config[obj_type].keys():
            mask_fields += psp_config[obj_type]["mask"]
        return hash_fields, mask_fields

    def __hash_value(self, value):
        """
        Overwrites the value of the field in the data object with the hashed value of the original value
        """
        v = str(value)
        return hashlib.sha256(v.encode("utf-8")).hexdigest()

    def __break_json_path(self, path):
        keys = path.split(".")
        subpaths = [keys[-1]]
        for i in range(len(keys) - 1, 0, -1):
            subpath = keys[i - 1] + "." + subpaths[-1]
            subpaths.append(subpath)
        return subpaths

    def __scrub(self, obj, prefix, sep=".") -> None:
        """
        Iterates through the JSON obj and identifies updates the hashed fields with a SHA256 hashing and the masked field with the string "***"
        """
        if prefix is None:
            prefix = []
        for key, value in obj.items():
            if isinstance(value, dict):
                self.__scrub(value, prefix + [key])
            elif isinstance(value, list):
                if len(value) == 0 or not isinstance(value[0], dict):
                    pass
                else:
                    for val in value:
                        self.__scrub(val, prefix + [key + "[*]"])
            else:
                path = sep.join(prefix + [key])
                path_list = set(self.__break_json_path(path))
                if len(path_list.intersection(self.hash_fields)) > 0:
                    obj[key] = self.__hash_value(value)
                elif len(path_list.intersection(self.mask_fields)) > 0:
                    obj[key] = "***"
                pass

    def scrub(self, obj):
        """
        Scrubs the object of PII
        :param obj: The object to scrub
        :return: The scrubbed object
        """
        self.__scrub(obj, None)
        return obj
