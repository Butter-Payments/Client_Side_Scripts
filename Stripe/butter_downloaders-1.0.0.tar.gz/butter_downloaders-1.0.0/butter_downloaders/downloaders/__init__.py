from abc import ABC, abstractmethod
from typing import Any, Dict


class DownloaderError(Exception):
    pass


class Downloader(ABC):
    """
    Base class for downloader.
    """

    def __init__(self):
        pass

    @abstractmethod
    def connect(self):
        """
        Creates a PSP client object if necessary.
        :return:
        """
        pass

    @abstractmethod
    def download(self, from_datetime: str, to_datetime: str):
        """
        Downloads transaction objects from the PSP within the provided beginning
        and ending datetimes.
        :param from_datetime: Starting datetime str
        :param to_datetime: Ending datetime str
        :return: List of transaction objects.
        """
        pass

    @abstractmethod
    def close(self):
        """
        Closes a PSP client object if necessary.
        :return:
        """
        pass


def to_dict(obj: Any) -> Dict:
    """
    Converts a nested object to a dict.
    """
    if isinstance(obj, dict):
        data = {}
        for k, v in obj.items():
            data[k] = to_dict(v)
        return data
    elif hasattr(obj, "__iter__") and not isinstance(obj, str):
        return [to_dict(v) for v in obj]
    elif hasattr(obj, "__dict__"):
        data = dict(
            [
                (key, to_dict(value))
                for key, value in obj.__dict__.items()
                if not callable(value) and not key.startswith("_")
            ]
        )
        return data
    else:
        return obj
