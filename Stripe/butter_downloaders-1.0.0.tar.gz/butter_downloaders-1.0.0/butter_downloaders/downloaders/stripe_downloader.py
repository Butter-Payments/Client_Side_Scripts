import math
import time
from typing import List

import dateutil.parser
import stripe
from stripe.api_resources import *  # noqa: F401, F403
from stripe.error import (
    APIConnectionError,
    AuthenticationError,
    InvalidRequestError,
    RateLimitError,
)

from butter_downloaders.downloaders import Downloader, DownloaderError
from butter_downloaders.utils.pii_scrubber import PIIScrubber

VALID_OBJECTS = [
    "Charge",
    "Coupon",
    "Customer",
    "Dispute",
    "Event",
    "Invoice",
    "PaymentIntent",
    "Payout",
    "Plan",
    "Price",
    "Product",
    "Refund",
    "Subscription",
]


class StripeDownloader(Downloader):
    """
    Downloads transactions from the Stripe API.
    """

    def __init__(self, api_key: str, object_type: str):
        self.api_key = api_key
        self.object_type_str = object_type
        if object_type in VALID_OBJECTS:
            self.object_type = globals()[object_type]
        else:
            print("No valid object type selected.")
            raise DownloaderError("No valid object type selected")
        self.scrubber = PIIScrubber("stripe", object_type.lower())
        super().__init__()

    def connect(self):
        stripe.api_key = self.api_key

    def download(self, from_datetime: str, to_datetime: str) -> List[str]:
        created_dict = dict(
            gte=int(dateutil.parser.parse(from_datetime).timestamp()),
            lt=int(dateutil.parser.parse(to_datetime).timestamp()),
        )
        debug_string = f"{from_datetime} to {to_datetime}"
        print(f"Downloading from {debug_string}", flush=True)
        result_objects = list()
        attempt = 0
        while True:
            try:
                download_kwargs = dict(
                    created=created_dict, limit=100, api_key=self.api_key
                )
                if self.object_type_str == "Subscription":
                    download_kwargs["status"] = "all"
                attempt += 1
                results = self.object_type.list(**download_kwargs)

                result_set = []
                for obj in results["data"]:
                    result_set.append(self.scrubber.scrub(obj))
                results["data"] = result_set
            # Rate limits are ok
            except RateLimitError:
                print(
                    f"Hit RateLimitError for {debug_string} on attempt {attempt}. Sleeping.",
                    flush=True,
                )
                time.sleep(math.pow(attempt, 2))
            # Temporary API error is ok
            except APIConnectionError:
                print(
                    f"Hit RateLimitError for {debug_string} on attempt {attempt}. Sleeping.",
                    flush=True,
                )
                time.sleep(math.pow(attempt, 2))
            # Not ok errors
            except InvalidRequestError:
                raise DownloaderError("Stripe InvalidRequestError")
            except AuthenticationError:
                raise DownloaderError("Stripe AuthenticationError")
            else:
                # results.data is a list of JSON
                result_objects.extend(results["data"])
                break

        pages = 0
        # Handle pagination. This is around 20% faster than using the OOTB auto-pagination tools.
        while results.has_more:
            pages += 1
            print(
                f"Additional results found for {debug_string}, fetching page {pages}",
                flush=True,
            )
            attempt = 0
            while True:
                try:
                    attempt += 1
                    download_kwargs = dict(
                        created=created_dict,
                        limit=100,
                        starting_after=results.data[-1]["id"],
                        api_key=self.api_key,
                    )
                    if self.object_type_str == "Subscription":
                        download_kwargs["status"] = "all"
                    results = self.object_type.list(**download_kwargs)
                    result_set = []
                    for obj in results["data"]:
                        result_set.append(self.scrubber.scrub(obj))
                    results["data"] = result_set
                except RateLimitError:
                    print(
                        f"Hit RateLimitError for {debug_string} on attempt {attempt}. Sleeping.",
                        flush=True,
                    )
                    time.sleep(math.pow(attempt, 2))
                except APIConnectionError:
                    print(
                        f"Hit RateLimitError for {debug_string} on attempt {attempt}. Sleeping.",
                        flush=True,
                    )
                    time.sleep(math.pow(attempt, 2))
                # Not ok errors
                except InvalidRequestError:
                    raise DownloaderError("Stripe InvalidRequestError")
                except AuthenticationError:
                    raise DownloaderError("Stripe AuthenticationError")
                else:
                    result_objects.extend(results["data"])
                    break

        return result_objects

    def close(self):
        pass
